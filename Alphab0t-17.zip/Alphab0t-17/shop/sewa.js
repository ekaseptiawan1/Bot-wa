const pc_sewa = () => {
return `「 *PRICE LIST* 」
							
⬣ PRICE SEWABOT

⬡ 1 MINGGU = Rp 5.000
⬡ 2 MINGGU = Rp 8.000
⬡ 3 MINGGU = Rp 10.000
⬡ 1 BULAN = Rp 15.000
⬡ PERMANEN = Rp 100.000
⬡ PERMANEN + USER PREM = Rp 150.000


⬣ PRICE JADIBOT

⬡ JADI BOT PERMANEN 25K


⬣ MINAT? PM
⬡ wa.me/62887435047326


NOTE : 
Bot On 24 Jam Karna Di Run Menggunakan Heroku
Reset Data Setiap Jam 02:00 `
	}

exports.pc_sewa = pc_sewa